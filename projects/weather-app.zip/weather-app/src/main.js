const LABELS = {
  0: "Despejedo",
  1: "Mayormente despejado",
  2: "Parcialmente nublado",
  3: "Nublado",
  45: "Niebla",
  48: "Niebla",
  51: "Llovizna",
  53: "Llovizna",
  51: "Llovizna",
  61: "Lluvia",
  63: "Lluvia",
  65: "Lluvia",
  71: "Nieve",
  73: "Nieve",
  75: "Nieve",
  80: "Chubascos",
  81: "Chubascos",
  82: "Chubascos",
  95: "Tormenta",
  96: "Tormenta",
  99: "Tormenta",
};

const env = import.meta.env;
const { VITE_GEOCODING_URL: GEO_URL, VITE_FORECAST_URL: API_URL } = env;

const $message = document.getElementById("message");
const $weather = document.getElementById("weather");

async function getJson(url) {
  const res = await fetch(url);
  console.log(res);

  if (!res.ok) throw new Error(`Error ${res.status}`);
  return res.json();
}

function urlWith(base, params) {
  const url = new URL(base);
  const lista = Object.entries(params);
  for (const [key, value] of lista) {
    url.searchParams.append(key, value);
  }
  return url;
}

function setMessage(text) {
  $message.textContent = text;
  $message.hidden = !Boolean(text);
}

async function showWeather(city) {
  setMessage("Cargando...");
  // Core
  const urlGeo = urlWith(GEO_URL, {
    name: city,
    count: 1,
    language: "es",
  });
  const geo = await getJson(urlGeo);

  const place = geo.results?.[0];

  if (!place) {
    setMessage(`No encontramos "${city}". Prueba con otro nombre.`);
    return;
  }

  const apiUrl = urlWith(API_URL, {
    latitude: place.latitude,
    longitude: place.longitude,
    current:
      "temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code",
    daily: "weather_code,temperature_2m_max,temperature_2m_min",
    timezone: "auto",
    forecast_days: 7,
  });

  const data = await getJson(apiUrl);

  const $place = document.getElementById("place");
  $place.textContent = place.country
    ? `${place.name}, ${place.country}`
    : place.name;

  const $temp = document.getElementById("temp");
  const t = data.current?.temperature_2m;
  $temp.textContent = Math.round(t) + "°";

  const $condition = document.getElementById("condition");
  $condition.textContent = LABELS[data.current?.weather_code];

  const $feels = document.getElementById("feels");
  const s = data.current?.apparent_temperature;
  $feels.textContent = Math.round(s) + "°";

  const $humidity = document.getElementById("humidity");
  const h = data.current?.relative_humidity_2m;
  $humidity.textContent = Math.round(h) + "%";

  const $wind = document.getElementById("wind");
  const v = data.current?.wind_speed_10m;
  $wind.textContent = Math.round(v) + "km/h";

  const $forecast = document.getElementById("forescast");
  const time = [...data.daily?.time].map((date, i) => {
    const fecha = new Date(`${date}T12:00:00Z`).toLocaleDateString("es-AR", {
      weekday: "long",
      timeZone: "UTC",
    });
    const day = i === 0 ? "Hoy" : fecha;

    const label = LABELS[data.daily?.weather_code[i]] ?? "Variable";
    const max = Math.round(data.daily?.temperature_2m_max[i]);
    const min = Math.round(data.daily?.temperature_2m_min[i]);

    return `
        <li>
            <div>
                <span class="day">${day}</span>
                <span class="desc">${label}</span>
            </div>
            <span class="temps">
                <strong>${max}°</strong>
                <strong>${min}°</strong>
            </span>
        </li>
    `;
  });

  $forecast.innerHTML = time.join("");

  //--

  $weather.hidden = false;
  setMessage("");
  try {
  } catch (error) {
    console.error(error);
    setMessage("No se pudo cargar el clima. Revisa tu conexión.");
  }
}

const $searchForm = document.getElementById("search-form");
$searchForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const $city = document.getElementById("city");
  const value = $city.value.trim();
  if (value) showWeather(value);
});

showWeather("Bariloche");

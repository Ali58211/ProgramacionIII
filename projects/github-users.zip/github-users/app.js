const API_URL = "https://api.github.com/users/";

const $main = document.getElementById("main");
const $form = document.getElementById("form");
const $search = document.getElementById("search");

async function getUser(username) {
  try {
    const res = await fetch(API_URL + username);
    if (res.status == 404) {
      // si el user no se encuentra
      createErrorCard("No profile with this username");
      return;
    }
    if (res.ok) {
      const data = await res.json();
      createUserCard(data);
      getRepos(username);
    }
  } catch (err) {
    createErrorCard("Problem fetching user");
  }
}

async function getRepos(username) {
  try {
    const res = await fetch(`${API_URL + username}/repos?sort=created`);
    if (res.ok) {
      const data = await res.json();
      addReposToCard(data);
    }
  } catch (err) {
    createErrorCard("Problem fetching user");
  }
}

function createErrorCard(msg) {
  //   const text = "hola que tal " + msg;
  const card = `
    <div class="card">
        <h1>${msg}</h1>
    </div>`;

  $main.innerHTML = card; // innerHTML reconoce la sintaxis
}

function createUserCard(user) {
  const userId = user.name ?? user.login;
  const userBio = user.bio ? `<p>${user.bio}</p>` : "-";

  const card = `
    <div class="card">
        <div>
            <img src="${user.avatar_url}" alt="${userId}" class="avatar" />
        </div>
        <div class="user-info">
            <h2>${userId}</h2>
            ${userBio}
            <ul>
                <li>${user.followers} <strong>Followers</strong></li>
                <li>${user.following} <strong>Following</strong></li>
                <li>${user.public_repos} <strong>Repos</strong></li>
            </ul>

            <div id="repos"></div>
        </div>
    </div>
  `;

  $main.innerHTML = card;
}

function addReposToCard(repos) {
  const $repos = document.getElementById("repos");

  repos.slice(0, 5).forEach((repo) => {
    const $repo = document.createElement("a");
    $repo.classList.add("repo");
    $repo.href = repo.html_url;
    $repo.terget = "_blank";
    $repo.innerText = repo.name;

    $repos.appendChild($repo);
  });
}

$form.addEventListener("submit", (evento) => {
  evento.preventDefault();

  const user = $search.value;

  if (user) {
    getUser(user);

    $search.value = "";
  }
});

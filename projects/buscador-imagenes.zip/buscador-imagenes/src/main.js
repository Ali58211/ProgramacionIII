const $form = document.querySelector("form");
const $search = document.getElementById("search");
const $results = document.querySelector(".results");

const { VITE_API_URL: apiUrl, VITE_API_KEY: key } = import.meta.env;

let page = 1;

async function searchImages() {
  let input = $search.value || "Gatitos"; //es una cadena vacia combiene el OR

  const url = new URL(apiUrl);
  url.searchParams.append("page", page);
  url.searchParams.append("query", input);
  url.searchParams.append("client_id", key);

  const res = await fetch(url);
  const { results } = await res.json();

  if (page == 1) {
    $results.innerHTML = "";
  }

  results?.forEach((result) => {
    const $wrapper = document.createElement("article");
    $wrapper.classList.add("search-result");

    const $image = document.createElement("img");
    $image.src = result.urls?.small;
    $image.alt = result.alt_description;

    const $link = document.createElement("a");
    $link.href = result.links?.html;
    $link.target = "_blank";
    $link.textContent = result.alt_description;

    $wrapper.append($image, $link);
    $results.appendChild($wrapper);
  });
}

$form.addEventListener("submit", (e) => {
  e.preventDefault();
  page = 1;
  searchImages();
});
